const Aboutus = () => {
    return ( 
        <div>
    <div className="my-5 mt-24 xl:py-10">
      <div className="flexing max-w-7xl mx-auto py-10">
      <div className="grid md:grid-cols-2 gap-4">
      <div className="comment">
      <h2 className="text-2xl font-bold">About us</h2>
      <p className="text-base peer">
       Your thesis may also be considered by different employers when processing your job application in the future. The high-quality of our completed dissertation examples have had a positive impact on our customer base over the years.
      Research papers assignment will be considered by your instructors when determining the final grade at the end of your studies. Hence, you should seek research writing to ensure that you submit a quality college paper that will guarantee good grades in the end. When you search for a research paper writing service cheap, you will realize that our company is one of the industrys top-ranked.
       </p>
       </div>
        <div className="">
        <img src="dissertation-help-and-capstone-project.jpg" alt="responsive web development" className="cardimg1"/>
      </div>
    </div>
    </div>
    </div>
  </div>
     );
}
 
export default Aboutus;