export const phone = ''
export const email = 'example@gmail.com'
export const host = 'https://app.topresearchpapers.com'
export const host2 = 'https://api.topresearchpapers.com'