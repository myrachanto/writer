/** @type {import('next-sitemap').IConfig} */
module.exports = {

  siteUrl: 'https://e.topresearchpapers.com',
  generateRobotsTxt: true,
  sitemapSize: 7000,
  }