"use strict";
(() => {
var exports = {};
exports.id = 195;
exports.ids = [195];
exports.modules = {

/***/ 2589:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ blog),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./utils/myrconstants.js
var myrconstants = __webpack_require__(5829);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/patches/blogitem.js




const Blogitem = ({ item  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: item && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "bg-gray-50 rounded overflow-hidden md:w-96 shadow-lg m-2",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/blog/" + item.url,
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: `${myrconstants/* host */.ho}/uploads/blog/${item.image}`,
                        alt: item.title,
                        width: 500,
                        height: 300,
                        priority: true,
                        className: "cardimg"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                    className: "md:my-2"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "md:m-4 text-base ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/blog/" + item.url,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                className: "text-lg coloring1 my-2 font-semibold hover:cursor-pointer",
                                children: item.title
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "text-base peer",
                            dangerouslySetInnerHTML: {
                                __html: item.body.substring(0, 200) + "..."
                            }
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "m-2 flex justify-end items-center coloring1 ",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/blog/" + item.url,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "hover:cursor-pointer font-bold",
                            children: "Read More"
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const blogitem = (Blogitem);

;// CONCATENATED MODULE: ./pages/blog/index.js



// import Portfo from "../components/patches/portfo";

const getStaticProps = async (context)=>{
    const res = await fetch(`${myrconstants/* host */.ho}/api/blog`);
    const data = await res.json();
    return {
        props: {
            items: data.articles
        },
        revalidate: 10
    };
};
const Blog = ({ items  })=>{
    // console.log("------------------", items)
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "my-5 mt-24",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "lg:mt-0",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "flex justify-center items-center font-semibold py-10",
                        children: "Blogs"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "max-w-7xl 2xl:mx-auto mx-4 grid lg:grid-cols-3 md:grid-cols-2",
                        children: items && items.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx(blogitem, {
                                item: item
                            }, item._id))
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const blog = (Blog);


/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [377,964,952,664,675,829], () => (__webpack_exec__(2589)));
module.exports = __webpack_exports__;

})();