(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 6769:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/script.js
var script = __webpack_require__(4298);
var script_default = /*#__PURE__*/__webpack_require__.n(script);
;// CONCATENATED MODULE: ./components/plugs/twak.js


const Twak = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
        id: "tawk",
        strategy: "lazyOnload",
        children: `
            var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
            (function(){
            var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
            s1.async=true;
            s1.src='https://embed.tawk.to/5b3caa196d961556373d65e7/default';
            s1.charset='UTF-8';
            s1.setAttribute('crossorigin','*');
            s0.parentNode.insertBefore(s1,s0);
            })();  
        `
    });
};
/* harmony default export */ const twak = (Twak);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/layouts/Foot.js


const Foot = ({ foot  })=>{
    // console.log('>>>>>>>>>>', foot)
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "flex justify-center items-center",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "main",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                className: "list-none mb-6",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "mt-2 mr-2 text-white md:block md:mr-0",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex justify-start items-center",
                            children: foot.title.head
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "mt-2 mr-2 text-white md:block md:mr-0",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: foot.link1.link,
                            className: "link",
                            children: foot.link1.head
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "mt-2 mr-2 text-white md:block md:mr-0",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: foot.link2.link,
                            className: "link",
                            children: foot.link2.head
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "mt-2 mr-2 text-white md:block md:mr-0",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: foot.link3.link,
                            className: "link",
                            children: foot.link3.head
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const layouts_Foot = (Foot);

;// CONCATENATED MODULE: ./components/layouts/Footer.js



const Footer = ()=>{
    const { 0: footers , 1: setFooters  } = (0,external_react_.useState)([
        {
            id: 1,
            title: {
                head: "Links",
                link: "#"
            },
            link1: {
                head: "FAQ",
                link: "#"
            },
            link2: {
                head: "Help",
                link: "#"
            },
            link3: {
                head: "classic",
                link: "#"
            }
        },
        {
            id: 2,
            title: {
                head: "Legal",
                link: "#"
            },
            link1: {
                head: "Terms",
                link: "#"
            },
            link2: {
                head: "Privacy",
                link: "#"
            },
            link3: {
                head: "Contract",
                link: "#"
            }
        },
        {
            id: 3,
            title: {
                head: "Firm",
                link: "#"
            },
            link1: {
                head: "Blog",
                link: "/blog"
            },
            link2: {
                head: "About Us",
                link: "/aboutus"
            },
            link3: {
                head: "Contact",
                link: "/contact"
            }
        },
        {
            id: 4,
            title: {
                head: "Social",
                link: "#"
            },
            link1: {
                head: "Facebook",
                link: "#"
            },
            link2: {
                head: "Twitter",
                link: "#"
            },
            link3: {
                head: "Instagram",
                link: "#"
            }
        }
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "coloring",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "max-w-7xl mx-auto",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex justify-between items-center flex-wrap px-4 lg:px-0 mx-4",
                    children: footers.map((foot)=>{
                        return /*#__PURE__*/ jsx_runtime_.jsx(layouts_Foot, {
                            foot: foot
                        }, foot.id);
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex flex-wrap justify-center items-center text-white mx-4",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "https://chantosweb.co.ke",
                        children: "  Developed by Chantosweb Developers"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const layouts_Footer = (Footer);

;// CONCATENATED MODULE: external "next/router"
const router_namespaceObject = require("next/router");
// EXTERNAL MODULE: ./utils/myrconstants.js
var myrconstants = __webpack_require__(5829);
;// CONCATENATED MODULE: ./components/layouts/Navbar.js





const Navbar = ({})=>{
    const router = (0,router_namespaceObject.useRouter)();
    const { 0: isOpen , 1: setIsOpen  } = (0,external_react_.useState)(false);
    const menuset = (e)=>{
        setIsOpen(isOpen = !isOpen);
    };
    (0,external_react_.useEffect)(()=>{
        try {
            setIsOpen(isOpen = false);
        } catch (err) {}
    }, [
        router
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "mb-5 max-w-7xl",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            id: "header",
            className: " w-full z-30 -top-1 bg-gray-100 fixed",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("hr", {}),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "coloring",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "px-2 2xl:px-0 max-w-7xl mx-auto flex md:justify-start items-center mt-0 py-3 ",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "grid md:grid-cols-2 ",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: " w-full flex order-1 flex-wrap",
                                        children: [
                                            " ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                onClick: menuset,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                    className: "cursor-pointer md:hidden flex px-4",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                                        className: "fill-current text-white ",
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        width: "20",
                                                        height: "20",
                                                        viewBox: "0 0 20 20",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("title", {
                                                                children: "menu"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                                d: "M0 3h20v2H0V3zm0 6h20v2H0V9zm0 6h20v2H0v-2z"
                                                            })
                                                        ]
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/",
                                                className: " ",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "py-1 px-4 2xl:px-0 font-bold text-lg text-white lg:text-2xl",
                                                    children: [
                                                        "Top",
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "text-orange-500",
                                                            children: "Research"
                                                        }),
                                                        "Papers"
                                                    ]
                                                })
                                            })
                                        ]
                                    }),
                                    isOpen ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                                        className: " md:hidden w-full order-2 text-white",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "px-2 py-1 capitalize font-bold",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/",
                                                    className: "no-underline font-bold ",
                                                    children: "HOME"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "px-2 py-1 capitalize font-bold",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/services",
                                                    className: "no-underline font-bold ",
                                                    children: "SERVICE"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "px-2 py-1 capitalize font-bold",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/questions",
                                                    className: "no-underline font-bold ",
                                                    children: "QUESTIONS"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "px-2 py-1 capitalize font-bold",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/aboutus",
                                                    className: "no-underline ",
                                                    children: "ABOUT US"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "px-2 py-1 capitalize font-bold",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/contact",
                                                    className: "no-underline ",
                                                    children: "CONTACT"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "px-2 py-1 capitalize font-bold",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/blog",
                                                    className: "no-underline ",
                                                    children: "BLOG"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "px-2 py-1 flex justify-start capitalize ",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "https://acemywriter.com/order/login",
                                                    className: "no-underline ",
                                                    children: "Login"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "px-2 py-1 flex justify-start capitalize ",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: "https://acemywriter.com/order/",
                                                    target: "_blank",
                                                    rel: "noreferrer",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        type: "submit",
                                                        className: " bg-orange-500 p-2 rounded-md",
                                                        children: "Order Now"
                                                    })
                                                })
                                            })
                                        ]
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "hidden"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "md:flex hidden justify-end px-2 2xl:px-0 items-center w-full order-2",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                                    className: "md:flex items-center justify-between text-sm text-white font-semibold",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "px-2 py-1 flex justify-start capitalize ",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/",
                                                className: "no-underline ",
                                                children: "HOME"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "px-2 py-1 flex justify-start capitalize ",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/services",
                                                className: "no-underline ",
                                                children: "SERVICE"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "px-2 py-1 flex justify-start capitalize ",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/questions",
                                                className: "no-underline ",
                                                children: "QUESTIONS"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "px-2 py-1 flex justify-start capitalize ",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/aboutus",
                                                className: "no-underline ",
                                                children: "ABOUT US"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "px-2 py-1 flex justify-start capitalize ",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/blog",
                                                className: "no-underline ",
                                                children: "BLOG"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "px-2 py-1 flex justify-start capitalize ",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/contact",
                                                className: "no-underline ",
                                                children: "CONTACT"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "px-2 py-1 flex justify-start capitalize ",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "https://acemywriter.com/order/login",
                                                className: "no-underline ",
                                                children: "Login"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "px-2 py-1 flex justify-start capitalize ",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "https://acemywriter.com/order/",
                                                target: "_blank",
                                                rel: "noreferrer",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    type: "submit",
                                                    className: " bg-orange-500 p-2 rounded-md",
                                                    children: "Order Now"
                                                })
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " lg:hidden flex items-center",
                                id: "nav-content",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "block md:hidden text-white font-semibold",
                                    children: myrconstants/* phone */.m7
                                })
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const layouts_Navbar = (Navbar);

;// CONCATENATED MODULE: ./components/layouts/Layout.js




function Layout({ children  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "content",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(layouts_Navbar, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                children: children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(twak, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(layouts_Footer, {})
        ]
    });
};

;// CONCATENATED MODULE: ./pages/_app.js



function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(Layout, {
            children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                ...pageProps
            })
        })
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 4298:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(699)


/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [377,964,952,664,829], () => (__webpack_exec__(6769)));
module.exports = __webpack_exports__;

})();