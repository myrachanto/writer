"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405,829];
exports.modules = {

/***/ 1524:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/patches/ordering.js
var ordering = __webpack_require__(9608);
// EXTERNAL MODULE: ./components/patches/portfo.js
var patches_portfo = __webpack_require__(3687);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/patches/section1.js


const Section1 = ({ footerContent , partb , partc1 , partc2 , partc3  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "my-5 py-5 mx-6 peer section1",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " max-w-7xl xl:mx-auto ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "text-base peer section1",
                        dangerouslySetInnerHTML: {
                            __html: footerContent
                        }
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flexing max-w-7xl xl:mx-auto mx-6",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "grid md:grid-cols-2 gap-4",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: " flex justify-center items-center",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        // loader={myLoader}
                                        src: "/dissertation-help-and-capstone-project.jpg",
                                        alt: "dissertation-help-and-capstone-project",
                                        width: 500,
                                        height: 300,
                                        priority: true,
                                        className: "w-full object-cover cursor-pointer cardimg1"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "text-base mt-8 peer ",
                                        dangerouslySetInnerHTML: {
                                            __html: partb
                                        }
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "grid md:grid-cols-3 gap-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-base mt-8 peer ",
                                dangerouslySetInnerHTML: {
                                    __html: partc1
                                }
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-base mt-8 peer ",
                                dangerouslySetInnerHTML: {
                                    __html: partc2
                                }
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-base mt-8 peer ",
                                dangerouslySetInnerHTML: {
                                    __html: partc3
                                }
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const section1 = (Section1);

;// CONCATENATED MODULE: ./components/patches/section2.js


const Section2 = ({ partd , partf1 , partf2 , partf3  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "my-2 mx-6 peer",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex justify-center items-center max-w-7xl mx-auto",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "grid md:grid-cols-2 gap-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-base mt-8 peer ",
                                    dangerouslySetInnerHTML: {
                                        __html: partd
                                    }
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex justify-center items-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    // loader={myLoader}
                                    src: "/business-plan-and-case-study.jpg",
                                    alt: "dissertation-help-and-capstone-project",
                                    width: 500,
                                    height: 300,
                                    priority: true,
                                    className: "w-full object-cover cursor-pointer cardimg1"
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: " max-w-7xl xl:mx-auto ",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "grid md:grid-cols-2 gap-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-base mt-8 peer ",
                                dangerouslySetInnerHTML: {
                                    __html: partf1
                                }
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-base mt-8 peer ",
                                dangerouslySetInnerHTML: {
                                    __html: partf2
                                }
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: " max-w-7xl xl:mx-auto ",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "text-base mt-8 peer ",
                        dangerouslySetInnerHTML: {
                            __html: partf3
                        }
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const section2 = (Section2);

// EXTERNAL MODULE: ./utils/myrconstants.js
var myrconstants = __webpack_require__(5829);
;// CONCATENATED MODULE: ./utils/mycalcdata.js
const order = {
    pragReport: false,
    spacing: "Double",
    pages: 1,
    writerLevel: "Standard",
    serviceType: "Writing from scratch",
    deadline: "6 days",
    academicLevel: "High school"
};
const levels = [
    {
        name: "Select level",
        rate: 1
    },
    {
        name: "High school",
        rate: 1.2
    },
    {
        name: "College",
        rate: 1.5
    },
    {
        name: "Undergraduate",
        rate: 1.8
    },
    {
        name: "Masters",
        rate: 2
    },
    {
        name: "PhD",
        rate: 2.5
    }
];
const writerLevels = [
    {
        level: "Standard",
        rate: 1.8
    },
    {
        level: "Premium",
        rate: 2.4
    },
    {
        level: "Platinum",
        rate: 2.8
    }
];
const times = [
    {
        name: "6 hrs",
        value: 6,
        charge: 0.85
    },
    {
        name: "12 hrs",
        value: 12,
        charge: 0.8
    },
    {
        name: "24 hrs",
        value: 24,
        charge: 0.75
    },
    {
        name: "2 days",
        value: 48,
        charge: 0.7
    },
    {
        name: "3 days",
        value: 72,
        charge: 0.65
    },
    {
        name: "4 days",
        value: 96,
        charge: 0.6
    },
    {
        name: "6 days",
        value: 144,
        charge: 0.55
    },
    {
        name: "8 days",
        value: 192,
        charge: 0.5
    },
    {
        name: "10 days",
        value: 240,
        charge: 0.45
    },
    {
        name: "14 days",
        value: 336,
        charge: 0.4
    },
    {
        name: "20 days",
        value: 480,
        charge: 0.35
    },
    {
        name: "30 days",
        value: 720,
        charge: 0.3
    },
    {
        name: "40 days",
        value: 960,
        charge: 0.25
    }
];
const services = [
    {
        name: "Writing from scratch",
        charge: 1
    },
    {
        name: "Editing and proofreading",
        charge: 0.85
    },
    {
        name: "Presentation",
        charge: 0.5
    }
];
const spacingOptions = [
    {
        name: "Single spacing"
    },
    {
        name: "Double"
    }
];

;// CONCATENATED MODULE: ./pages/index.js



// import Carocard from '../components/patches/Carocard'






const getStaticProps = async ()=>{
    const res = await fetch(`${myrconstants/* host */.ho}/api/seo/home`);
    const data = await res.json();
    // console.log(">>>>>>>>>>>>>>>>>>>", data)
    return {
        props: {
            meta: data.meta
        },
        revalidate: 10
    };
};
function Home({ meta  }) {
    const { 0: portfolio , 1: setPortfolio  } = (0,external_react_.useState)([
        {
            title: "Great customer reviews",
            content: "A satisfied customer is the best business strategy. We have satisfied thousands of customers and it can be seen on the reviews section. This has earned us retrun customers and referals which has enabled us to reach thousands of students online",
            icon: "top/calendar.png"
        },
        {
            title: "Urgent Assignment Help",
            content: "Our Writers are available 24/7 and can handle any order as little as 3 hours Deadline and deliver excellent assignment. Feel free to contact our support which is always available to serve you through our live chat and email or whatsApp and your wish is our command.",
            icon: "top/supp.png"
        },
        {
            title: "Private and confidential",
            content: "Customer privacy is crucial and we ensure that third parties do not have access to your information. We also do not resell any orders from our clients and hence your assignment is safe with us",
            icon: "top/secure.png"
        },
        {
            title: "US native writers available",
            content: "We have ENL and ESL writers and hence we serve native students and international students seeking online assignment help. We can match every client with their desired quality and hence we have attained a substantial market commend",
            icon: "top/writer.png"
        },
        {
            title: "Proffesional Editors",
            content: "Our editors have PHD from different fields and they will edit your paper to top notch quality before submitting it to you. We match each assignment who has the field qualification and hence proffesional and high quality assignment guarunteed",
            icon: "top/edit.png"
        },
        {
            title: "Quality writers",
            content: "All our writers are verified and scrutinized for quality maintainance purposes. We also ensure that we regulary trainour writers regrading new writting standards and hence always deliver updated quality content and formats",
            icon: "top/us.png"
        }
    ]);
    const { 0: page , 1: setPage  } = (0,external_react_.useState)(1);
    const { 0: level , 1: setLevel  } = (0,external_react_.useState)("High school");
    const { 0: writer , 1: setWriter  } = (0,external_react_.useState)("Standard");
    const { 0: deadline , 1: setDeadline  } = (0,external_react_.useState)("6 days");
    const { 0: service , 1: setService  } = (0,external_react_.useState)("Writing from scratch");
    const { 0: spacing , 1: setSpacing  } = (0,external_react_.useState)("Double");
    const { 0: total , 1: setTotal  } = (0,external_react_.useState)();
    (0,external_react_.useEffect)(()=>{
        try {
            console.log("-----------------> whhhhhhhhhhhhhh");
            const _level = levels.find((item)=>{
                return item.name === level;
            });
            const levelwite = _level ? _level.rate : 1;
            // console.log("----------------->level", level)
            //  console.log(level, 'level')
            const charge = times.find((t)=>{
                return t.name === deadline;
            }) || false;
            //  console.log('Charge', charge)
            const timeCharge = charge ? charge.charge : 1;
            // console.log("----------------->timeCharge", timeCharge)
            const _serviceType = services.find((s)=>{
                return s.name === service;
            });
            const serviceType = _serviceType ? _serviceType.charge : 1;
            // console.log("----------------->serviceType", serviceType)
            // const _spacing = spacingOptions.find((s) => { return s.name === spacing })
            let pagespacing = spacing === "Single spacing" ? 2 : 1;
            console.log("----------------->spacing ", pagespacing);
            const _wLevel = writerLevels.find((l)=>{
                return l.level === writer;
            });
            const wLevel = _wLevel ? _wLevel.rate : 1;
            // console.log("----------------->wLevel", wLevel)
            // const pragReport = this.order.pragReport ? 5 : 0
            const pragReport = 1;
            const _page = page;
            // console.log("----------------->pragReport", pragReport)
            // console.log(this.order.pages, level, timeCharge, wLevel, spacing, serviceType, 18)
            const price = _page * levelwite * timeCharge * wLevel * pagespacing * serviceType * 13 + pragReport;
            // console.log("----------------->pragReport", price)
            setTotal((total)=>price.toFixed(2));
        } catch  {
            console.log("-------------->>>>>>>>>>>");
        }
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    meta && /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: meta.metaTitle
                    }) || /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Writer "
                    }),
                    meta && /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: meta.metaDescription
                    }) || /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Generated by create next app"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "bg-blue-700",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "max-w-7xl mx-auto pt-10 coloring1 hidden 2xl:block gradient",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: " hidden caroheigths w-full pt-16 lg:grid grid-cols-2 gap-10 relative isolate",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "hidden lg:block absolute top-60 left-72",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "trace.svg",
                                        alt: "responsive web development",
                                        className: ""
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "hidden lg:block absolute text-black top-28 z-30 bg-slate-50 p-2 comme",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "font-bold",
                                            children: "Excellent"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-sm",
                                            children: "Based on 167 customer’s reviews"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "hidden lg:block absolute text-black bottom-36 left-60 z-30 p-2 helps bg-orange-200",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "font-bold",
                                            children: "Hi there!"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-sm",
                                            children: "Our expert writers are ready to help."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "hidden lg:block absolute top-44 picsider",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "dissertation-help-and-capstone-project.jpg",
                                        alt: "responsive web development",
                                        className: "h-16 rounded-full w-16 object-cover"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "hidden lg:block absolute bottom-44 left-96 z-30 ",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "business-plan-and-case-study.jpg",
                                        alt: "responsive web development",
                                        className: "h-16 rounded-full w-16 object-cover"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "hidden lg:block absolute top-24 right-10 rounded-2xl bg-slate-300 text-black",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                        className: " w-96 px-4",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex justify-between items-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "text-2xl my-2 py-2",
                                                        children: "Calculate the price of your order"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {})
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                                    className: " px-2 py-2 rounded-lg w-full mt-2",
                                                    value: level,
                                                    onChange: (e)=>setLevel(e.target.value),
                                                    children: levels && levels.map((level)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                            value: level.name,
                                                            children: level.name
                                                        }, level.name))
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                                    className: " px-2 py-2 rounded-lg w-full mt-2",
                                                    value: writer,
                                                    onChange: (e)=>setWriter(e.target.value),
                                                    children: writerLevels && writerLevels.map((writer)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                            value: writer.level,
                                                            children: writer.level
                                                        }, writer.level))
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                                    className: " px-2 py-2 rounded-lg w-full mt-2",
                                                    value: deadline,
                                                    onChange: (e)=>setDeadline(e.target.value),
                                                    children: times && times.map((tim)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                            value: tim.charge,
                                                            children: tim.name
                                                        }, tim.name))
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                                    className: " px-2 py-2 rounded-lg w-full mt-2",
                                                    value: service,
                                                    onChange: (e)=>setService(e.target.value),
                                                    children: services && services.map((ser)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                            value: ser.name,
                                                            children: ser.name
                                                        }, ser.name))
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "my-2 flex justify-between ",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                        children: [
                                                            "Number of pages",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "text-gray-500 text-sm",
                                                                children: "275 words"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                        type: "number",
                                                        value: page,
                                                        name: "phone",
                                                        onChange: (e)=>setPage(e.target.value),
                                                        className: "inpus"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                                    className: " px-2 py-2 rounded-lg w-full mt-2",
                                                    value: spacing,
                                                    onChange: (e)=>setSpacing(e.target.value),
                                                    children: spacingOptions && spacingOptions.map((space)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                            value: space.name,
                                                            children: space.name
                                                        }, space.name))
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: " flex justify-between items-center my-3",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                                                    total && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "text-2xl font-bold",
                                                        children: [
                                                            "$ ",
                                                            total
                                                        ]
                                                    }) || /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "text-2xl font-bold",
                                                        children: "$9.99"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: "https://acemywriter.com/order/",
                                                    target: "_blank",
                                                    rel: "noreferrer",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        className: "rounded-lg bg-blue-700 w-full my-4 p-3 text-white font-semibold",
                                                        children: "Continue to Order"
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "h-7/12 hidden lg:block bg-blue-800 rounded-3xl text-white",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "my-20 ml-5",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                className: " text-sm bg-blue-900 px-3 py-2 rounded-2xl",
                                                children: "Save 15%! Use FIRST-ORDER discount code  "
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                            className: " mx-8 text-4xl font-bold",
                                            children: meta.h1
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "mx-8 mt-8 text-lg",
                                            children: meta.capture
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "h-7/12 bg-blue-800 rounded-3xl mt-20"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "max-w-7xl 2xl:hidden mx-auto coloring1 bg-blue-700 gradient",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: " hidden caroheigth w-full pt-16 lg:grid grid-cols-2 gap-10 relative isolate",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "hidden lg:block absolute top-60 left-72",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "trace.svg",
                                            alt: "responsive web development",
                                            className: ""
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "hidden lg:block absolute text-black top-28 z-30 bg-slate-50 p-2 comme",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "font-bold",
                                                children: "Excellent"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "text-sm",
                                                children: "Based on 167 customer’s reviews"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "hidden lg:block absolute text-black bottom-36 left-60 z-30 p-2 helps bg-orange-200",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "font-bold",
                                                children: "Hi there!"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "text-sm",
                                                children: "Our expert writers are ready to help."
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "hidden lg:block absolute top-44 picsider",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "dissertation-help-and-capstone-project.jpg",
                                            alt: "responsive web development",
                                            className: "h-16 rounded-full w-16 object-cover"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "hidden lg:block absolute bottom-44 left-96 z-30 ",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "business-plan-and-case-study.jpg",
                                            alt: "responsive web development",
                                            className: "h-16 rounded-full w-16 object-cover"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "hidden lg:block absolute top-24 right-10 rounded-2xl bg-slate-300 text-black",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                            className: " w-96 px-4",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex justify-between items-center",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "text-2xl my-2 py-2",
                                                            children: "Calculate the price of your order"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {})
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                                        className: " px-2 py-2 rounded-lg w-full mt-2",
                                                        value: level,
                                                        onChange: (e)=>setLevel(e.target.value),
                                                        children: levels && levels.map((level)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                value: level.name,
                                                                children: level.name
                                                            }, level.name))
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                                        className: " px-2 py-2 rounded-lg w-full mt-2",
                                                        value: writer,
                                                        onChange: (e)=>setWriter(e.target.value),
                                                        children: writerLevels && writerLevels.map((writer)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                value: writer.level,
                                                                children: writer.level
                                                            }, writer.level))
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                                        className: " px-2 py-2 rounded-lg w-full mt-2",
                                                        value: deadline,
                                                        onChange: (e)=>setDeadline(e.target.value),
                                                        children: times && times.map((tim)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                value: tim.charge,
                                                                children: tim.name
                                                            }, tim.name))
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                                        className: " px-2 py-2 rounded-lg w-full mt-2",
                                                        value: service,
                                                        onChange: (e)=>setService(e.target.value),
                                                        children: services && services.map((ser)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                value: ser.name,
                                                                children: ser.name
                                                            }, ser.name))
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "my-2 flex justify-between ",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                            children: [
                                                                "Number of pages",
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "text-gray-500 text-sm",
                                                                    children: "275 words"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            type: "number",
                                                            value: page,
                                                            name: "phone",
                                                            onChange: (e)=>setPage(e.target.value),
                                                            className: "inpus"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                                        className: " px-2 py-2 rounded-lg w-full mt-2",
                                                        value: spacing,
                                                        onChange: (e)=>setSpacing(e.target.value),
                                                        children: spacingOptions && spacingOptions.map((space)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                value: space.name,
                                                                children: space.name
                                                            }, space.name))
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: " flex justify-between items-center my-3",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                                                        total && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "text-2xl font-bold",
                                                            children: [
                                                                "$ ",
                                                                total
                                                            ]
                                                        }) || /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "text-2xl font-bold",
                                                            children: "$9.99"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "https://acemywriter.com/order/",
                                                        target: "_blank",
                                                        rel: "noreferrer",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            className: "rounded-lg bg-blue-700 w-full my-4 p-3 text-white font-semibold",
                                                            children: "Continue to Order"
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "h-screen hidden lg:block bg-blue-800 rounded-3xl text-white",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "my-20 ml-5",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: " text-sm bg-blue-900 px-3 py-2 rounded-2xl",
                                                    children: "Save 15%! Use FIRST-ORDER discount code  "
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                className: " mx-8 text-4xl font-bold",
                                                children: meta.h1
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "mx-8 mt-8 text-lg",
                                                children: meta.capture
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "h-screen bg-blue-800 rounded-3xl mt-20"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "grid sm:grid-cols-3 md:hidden relative ",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "absolute right-12 bottom-52",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "dissertation-help-and-capstone-project.jpg",
                                            alt: "responsive web development",
                                            className: "h-28 rounded-full w-28 object-cover"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "absolute left-32 bottom-5",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "business-plan-and-case-study.jpg",
                                            alt: "responsive web development",
                                            className: "h-28 rounded-full w-28 object-cover"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: " absolute text-black bottom-64 left-2 bg-slate-50 p-2 commemobile",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "font-bold",
                                                children: "Excellent"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "text-sm",
                                                children: "Based on 167 customer’s reviews"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "absolute text-black bottom-20 left-52 z-30 p-2 helpsmobile bg-orange-200",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "font-bold",
                                                children: "Hi there!"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "text-sm",
                                                children: "Our expert writers are ready to help."
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "lg:hidden absolute -bottom-96 contcal right-12 rounded-2xl bg-slate-300 text-black",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                            className: " w-80 px-4",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex justify-between items-center",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "text-2xl my-2 py-2",
                                                            children: "Calculate the price of your order"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {})
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                                        className: " px-2 py-2 rounded-lg w-full mt-2",
                                                        value: level,
                                                        onChange: (e)=>setLevel(e.target.value),
                                                        children: levels && levels.map((level)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                value: level.name,
                                                                children: level.name
                                                            }, level.name))
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                                        className: " px-2 py-2 rounded-lg w-full mt-2",
                                                        value: writer,
                                                        onChange: (e)=>setWriter(e.target.value),
                                                        children: writerLevels && writerLevels.map((writer)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                value: writer.level,
                                                                children: writer.level
                                                            }, writer.level))
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                                        className: " px-2 py-2 rounded-lg w-full mt-2",
                                                        value: deadline,
                                                        onChange: (e)=>setDeadline(e.target.value),
                                                        children: times && times.map((tim)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                value: tim.charge,
                                                                children: tim.name
                                                            }, tim.name))
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                                        className: " px-2 py-2 rounded-lg w-full mt-2",
                                                        value: service,
                                                        onChange: (e)=>setService(e.target.value),
                                                        children: services && services.map((ser)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                value: ser.name,
                                                                children: ser.name
                                                            }, ser.name))
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "my-2 flex justify-between ",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                            children: [
                                                                "Number of pages",
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "text-gray-500 text-sm",
                                                                    children: "275 words"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            type: "number",
                                                            value: page,
                                                            name: "phone",
                                                            onChange: (e)=>setPage(e.target.value),
                                                            className: "inpus"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                                        className: " px-2 py-2 rounded-lg w-full mt-2",
                                                        value: spacing,
                                                        onChange: (e)=>setSpacing(e.target.value),
                                                        children: spacingOptions && spacingOptions.map((space)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                value: space.name,
                                                                children: space.name
                                                            }, space.name))
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: " flex justify-between items-center my-3",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                                                        total && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "text-2xl font-bold",
                                                            children: [
                                                                "$ ",
                                                                total
                                                            ]
                                                        }) || /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "text-2xl font-bold",
                                                            children: "$9.99"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "https://acemywriter.com/order/",
                                                        target: "_blank",
                                                        rel: "noreferrer",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            className: "rounded-lg bg-blue-700 w-full my-2 p-3 text-white font-semibold",
                                                            children: "Continue to Order"
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "text-white",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "mt-20 flex justify-center items-center",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: " text-sm bg-blue-900 text-white px-3 py-2 rounded-2xl",
                                                    children: "Save 15%! Use FIRST-ORDER discount code  "
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                className: " mx-8 my-5 text-2xl font-bold text-center",
                                                children: meta.h1
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: " text-lg text-center py-5",
                                                children: meta.capture
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "mx-4",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "trace.svg",
                                            alt: "responsive web development",
                                            className: ""
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {})
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "md:grid md:grid-cols-2 hidden lg:hidden relative mt-10",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "absolute right-12 bottom-52",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "dissertation-help-and-capstone-project.jpg",
                                            alt: "responsive web development",
                                            className: "h-28 rounded-full w-28 object-cover"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "absolute right-64 bottom-20",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "business-plan-and-case-study.jpg",
                                            alt: "responsive web development",
                                            className: "h-28 rounded-full w-28 object-cover"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: " absolute text-black top-20 right-32 bg-slate-50 p-2 commemobile",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "font-bold",
                                                children: "Excellent"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "text-sm",
                                                children: "Based on 167 customer’s reviews"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "absolute text-black bottom-24 right-10 z-30 p-2 helpsmobile bg-orange-200",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "font-bold",
                                                children: "Hi there!"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "text-sm",
                                                children: "Our expert writers are ready to help."
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "hidden md:block absolute -bottom-96 contcals right-32 rounded-2xl bg-slate-300 text-black",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                            className: " w-full px-4",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex justify-between items-center",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "text-2xl my-2 py-2",
                                                            children: "Calculate the price of your order"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {})
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                                        className: " px-2 py-2 rounded-lg w-full mt-2",
                                                        value: level,
                                                        onChange: (e)=>setLevel(e.target.value),
                                                        children: levels && levels.map((level)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                value: level.name,
                                                                children: level.name
                                                            }, level.name))
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                                        className: " px-2 py-2 rounded-lg w-full mt-2",
                                                        value: writer,
                                                        onChange: (e)=>setWriter(e.target.value),
                                                        children: writerLevels && writerLevels.map((writer)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                value: writer.level,
                                                                children: writer.level
                                                            }, writer.level))
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                                        className: " px-2 py-2 rounded-lg w-full mt-2",
                                                        value: deadline,
                                                        onChange: (e)=>setDeadline(e.target.value),
                                                        children: times && times.map((tim)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                value: tim.charge,
                                                                children: tim.name
                                                            }, tim.name))
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                                        className: " px-2 py-2 rounded-lg w-full mt-2",
                                                        value: service,
                                                        onChange: (e)=>setService(e.target.value),
                                                        children: services && services.map((ser)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                value: ser.name,
                                                                children: ser.name
                                                            }, ser.name))
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "my-2 flex justify-between ",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                            children: [
                                                                "Number of pages",
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "text-gray-500 text-sm",
                                                                    children: "275 words"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            type: "number",
                                                            value: page,
                                                            name: "phone",
                                                            onChange: (e)=>setPage(e.target.value),
                                                            className: "inpus"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                                        className: " px-2 py-2 rounded-lg w-full mt-2",
                                                        value: spacing,
                                                        onChange: (e)=>setSpacing(e.target.value),
                                                        children: spacingOptions && spacingOptions.map((space)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                value: space.name,
                                                                children: space.name
                                                            }, space.name))
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: " flex justify-between items-center my-3",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                                                        total && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "text-2xl font-bold",
                                                            children: [
                                                                "$ ",
                                                                total
                                                            ]
                                                        }) || /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "text-2xl font-bold",
                                                            children: "$9.99"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "https://acemywriter.com/order/",
                                                        target: "_blank",
                                                        rel: "noreferrer",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            className: "rounded-lg bg-blue-700 w-full my-2 p-3 text-white font-semibold",
                                                            children: "Continue to Order"
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "text-white",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "mt-20 flex justify-start items-center",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: " text-sm bg-blue-900 text-white px-3 py-2 mx-6 rounded-2xl",
                                                    children: "Save 15%! Use FIRST-ORDER discount code  "
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                className: " mx-8 my-5 text-2xl font-bold ",
                                                children: meta.h1
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: " text-lg mx-6 py-5",
                                                children: meta.capture
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "mx-4",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "trace.svg",
                                            alt: "responsive web development",
                                            className: ""
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {})
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mt-96 lg:mt-0",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "flex justify-center items-center font-semibold py-5",
                        children: "Why Us?"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "max-w-7xl 2xl:mx-auto mx-4 grid lg:grid-cols-3 md:grid-cols-2",
                        children: portfolio && portfolio.map((portfo)=>/*#__PURE__*/ jsx_runtime_.jsx(patches_portfo/* default */.Z, {
                                portfo: portfo
                            }, portfo.title))
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ordering/* default */.Z, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(section1, {
                footerContent: meta.footerContent,
                partb: meta.partb,
                partc1: meta.partc1,
                partc2: meta.partc2,
                partc3: meta.partc3
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ordering/* default */.Z, {
                title: "Place an Order"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "bg-slate-100 my-3 py-3",
                children: /*#__PURE__*/ jsx_runtime_.jsx(section2, {
                    partd: meta.partd,
                    partf1: meta.partf1,
                    partf2: meta.partf2,
                    partf3: meta.partf3
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "-mb-5",
                children: /*#__PURE__*/ jsx_runtime_.jsx(ordering/* default */.Z, {})
            })
        ]
    });
};


/***/ }),

/***/ 5829:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B": () => (/* binding */ host2),
/* harmony export */   "Do": () => (/* binding */ email),
/* harmony export */   "ho": () => (/* binding */ host),
/* harmony export */   "m7": () => (/* binding */ phone)
/* harmony export */ });
const phone = "";
const email = "example@gmail.com";
const host = "https://app.topresearchpapers.com";
const host2 = "https://api.topresearchpapers.com";


/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [377,964,675,608,687], () => (__webpack_exec__(1524)));
module.exports = __webpack_exports__;

})();