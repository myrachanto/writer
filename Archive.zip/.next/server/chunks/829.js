"use strict";
exports.id = 829;
exports.ids = [829];
exports.modules = {

/***/ 5829:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B": () => (/* binding */ host2),
/* harmony export */   "Do": () => (/* binding */ email),
/* harmony export */   "ho": () => (/* binding */ host),
/* harmony export */   "m7": () => (/* binding */ phone)
/* harmony export */ });
const phone = "";
const email = "example@gmail.com";
const host = "https://app.topresearchpapers.com";
const host2 = "https://api.topresearchpapers.com";


/***/ })

};
;